package com.capgemini.demo;

import java.security.Timestamp;
import java.sql.Time;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		EntityManagerFactory emf = Persistence.createEntityManagerFactory("hello");
		EntityManager em = emf.createEntityManager();	
		

		em.getTransaction().begin();//-----------------------------begin transaction
		
		
		Actor actor = new Actor(1, "salman", "khan", "male", new Date(), new Date());
		em.persist(actor);
		
		
		Film film = new Film(1, "sultan", "UA", "2016", "English", (byte) 4 , null, (short) 90, null);
		em.persist(film);
		
		
		Album album = new Album(1, "salman", null, null);
		em.persist(album);
		
		Category category = new Category(1, "Horrer", null, null);
		em.persist(category);
		
		Image image = new Image(1, "www.google.com", null, null);
		em.persist(image);
		
			
		
		
		em.getTransaction().commit();//----------------------------Transaction ends
		
		em.close();
		emf.close();
	}

}
