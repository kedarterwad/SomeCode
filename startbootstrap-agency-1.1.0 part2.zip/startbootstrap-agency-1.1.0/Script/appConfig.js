var product= angular.module("productDetails",[]);

