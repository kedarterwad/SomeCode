function displaymrp(){
	
	var mrp=productForm.mrp.value;
	//alert(sal);
	document.getElementById('productMrp').innerHTML=mrp;
	
}

function isObject(arg) {
	  return Object.prototype.toString.call(arg)==='[object Object]';
	}


function formDataToObject(elForm) {
  if (!elForm instanceof Element) return;
  var fields = elForm.querySelectorAll('input, select, textarea'),
    o = {};
  for (var i=0, imax=fields.length; i<imax; ++i) {
    var field = fields[i],
      sKey = field.name || field.id;
    if (field.type==='button' || field.type==='submit' || !sKey) continue;
    switch (field.type) {
      
      case 'select-multiple':
        var a = [];
        for (var j=0, jmax=field.options.length; j<jmax; ++j) {
          if (field.options[j].selected) a.push(field.options[j].value);
        }
        o[sKey] = a;
        break;
      default:
        o[sKey] = field.value;
    }
  }
  alert('Form data:\n\n' + JSON.stringify(o, null, 2));
  return o;
}
