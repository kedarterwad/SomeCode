$( "#datepicker" ).datepicker({
	inline: true
})