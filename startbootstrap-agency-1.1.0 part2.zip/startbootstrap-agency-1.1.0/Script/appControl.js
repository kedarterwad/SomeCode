product.controller("categoryList",function($scope,$http){
	
	var url='http://localhost:8080/FinalPMS/CategoryServlets';
	
	$http.get(url)
		.success(function(response){
			
			$scope.categories=response;
		})
		.error(function(msg){
			$scope.categories=msg;
		});
	
});

product.controller("subcategoryList",function($scope,$http){
	
	var url='http://localhost:8080/FinalPMS/SubcategoryServlet';
	
	$http.get(url)
		.success(function(response){
			$scope.subCategories=response;
		})
		.error(function(msg){
			$scope.subCategories=msg;
		});
	
});

product.controller("supplierList",function($scope,$http){
	
	var url='http://localhost:8080/FinalPMS/SupplierServlet';
	
	$http.get(url)
		.success(function(response){
			$scope.suppliers=response;
		})
		.error(function(msg){
			$scope.suppliers=msg;
		});
	
});

product.controller("discountList",function($scope,$http){
	
	var url='http://localhost:8080/FinalPMS/DiscountServlet';
	
	$http.get(url)
		.success(function(response){
			$scope.discounts=response;
		})
		.error(function(msg){
			$scope.discounts=msg;
		});
	
});

//this method is for listing all products
product.controller("productList",function($scope,$http){
	
	var url='http://localhost:8080/FinalPMS/ProductListServlet';
	
	$http.get(url)
		.success(function(response){
			$scope.products=response;
		})
		.error(function(msg){
			$scope.products=msg;
		});
	
});

product.controller("searchedProducts",function($scope,$http){
	
	var url='http://localhost:8080/FinalPMS/SearchJson';
	
	$http.get(url)
		.success(function(response){
			$scope.searches=response;
		})
		.error(function(msg){
			$scope.searches=msg;
		});
	
});


