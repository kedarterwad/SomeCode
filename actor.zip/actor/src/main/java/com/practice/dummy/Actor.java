package com.practice.dummy;


import java.util.Date;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;

@Entity
public class Actor
{
	@Id @GeneratedValue(strategy=GenerationType.TABLE) 
	private int id;
	
	private String firstName;
	private String lastName;
	private String gender;
	
	@OneToOne
	private Album album;
	
	private Date createDate;
	private Date deleteDate;
	
	@ManyToMany//(mappedBy="actor")
	private List<Film> film;
	
	public Actor()
	{
		super();
	}

	
	/*public Actor(String firstName, String lastName, String gender, Album album, Date createDate,
			Date deleteDate, List<Film> film) 
	{
		super();
	//	this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;
		this.album = album;
		this.createDate = createDate;
		this.deleteDate = deleteDate;
		this.film = film;
	}*/

	public int getId() 
	{
		return id;
	}

	public void setId(int id) 
	{
		this.id = id;
	}

	public String getFirstName() 
	{
		return firstName;
	}

	public void setFirstName(String firstName)
	{
		this.firstName = firstName;
	}

	public String getLastName()
	{
		return lastName;
	}

	public void setLastName(String lastName) 
	{
		this.lastName = lastName;
	}

	public String getGender() 
	{
		return gender;
	}

	public void setGender(String gender)
	{
		this.gender = gender;
	}

	public Album getAlbum()
	{
		return album;
	}

	public void setAlbum(Album album)
	{
		this.album = album;
	}

	public Date getCreateDate() 
	{
		return createDate;
	}

	public void setCreateDate(Date createDate)
	{
		this.createDate = createDate;
	}

	public Date getDeleteDate() 
	{
		return deleteDate;
	}

	public void setDeleteDate(Date deleteDate) 
	{
		this.deleteDate = deleteDate;
	}


	public List<Film> getFilm() 
	{
		return film;
	}


	public void setFilm(List<Film> film)
	{
		this.film = film;
	}

	@Override
	public String toString() 
	{
		return "Actor [id=" + id + ", firstName=" + firstName + ", lastName=" + lastName + ", gender=" + gender
				+ ", album=" + album + ", createDate=" + createDate + ", deleteDate=" + deleteDate + ", film=" + film
				+ "]";
	}

}
