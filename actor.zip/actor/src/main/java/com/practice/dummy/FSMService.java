package com.practice.dummy;

import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;

import com.practice.dummy.Actor;
import com.practice.dummy.Album;
import com.practice.dummy.Category;
import com.practice.dummy.Film;

// import example.jpa.Employee;

public class FSMService 
{
	
	protected EntityManager em;
	public FSMService(EntityManager em)
	{
		this.em=em;
	}
	
	public FSMService() 
	{
	}

	public Film createFilm(Date createDate, String description, String language, short length, byte rating, Date releaseYear,
			String title)// List<Actor> actor, List<Category> category, Album album)
	{
		Film f = new Film();
		f.setTitle(title);
		f.setDescriptor(description);
		f.setReleaseDate(releaseYear);
		f.setLanguage(language);
		//f.setActor(actor);
		//f.setCategory(category);
		f.setRating(rating);
		f.setCreateDate(createDate);
		f.setLength(length);
		//f.setAlbum(album);
		em.persist(f);
		return f;
		
	}
	
	
	public Actor createActor(String firstName, String lastName, String gender, Date createDate,
			Date deleteDate)
	{
		Actor actor = new Actor();
		actor.setFirstName(firstName);
		actor.setLastName(lastName);
		actor.setGender(gender);
		actor.setCreateDate(createDate);
		actor.setDeleteDate(deleteDate);
		em.persist(actor);
		return actor;
	}

	
	public Image createImage(String imageUrl, Date createDate, Date deleteDate)
	{
		Image image = new Image();
		image.setImageUrl(imageUrl);
		image.setCreateDate(createDate);
		image.setDeleteDate(deleteDate);
		em.persist(image);
		return image;
	}
	
	
	public Album createAlbum(String albumName, Date createDate, Date deleteDate)
	{
		Album album = new Album();
		album.setAlbumName(albumName);
		album.setCreateDate(createDate);
		album.setDeleteDate(deleteDate);
		em.persist(album);
		return album;
		
	}
	
	
	public Category createCategory(String name, Date createDate, Date deleteDate)
	{
		Category category = new Category();
		category.setName(name);
		category.setCreateDate(createDate);
		category.setDeleteDate(deleteDate);
		em.persist(category);
		return category;
		
	}
	
	public Film setFilmCredentials(/*String title, */List<Actor> actor, List<Category> category, Album album)
	{
		Film filmExtra = new Film();
	
		
	/*	for(Film f : new Actor().getFilm())
		{
			if(f.getTitle()==title)
			{
			*/	filmExtra.setActor(actor);
				filmExtra.setCategory(category);
				filmExtra.setAlbum(album);
	/*			
			}
		}*/
		
		em.persist(filmExtra);
		return filmExtra;
	}
	
	public Actor setActorCredentials(List<Film> film, Album album)
	{
		Actor actorExtra = new Actor();
		actorExtra.setFilm(film);
		actorExtra.setAlbum(album);
		em.persist(actorExtra);
		return actorExtra;
	}
	
	public Album setAlbumCredentials(List<Image> image)
	{
		Album albumExtra = new Album();
		albumExtra.setImage(image);
		em.persist(albumExtra);
		return albumExtra;
	}
	
	
	public Category setCategoryCredentials(List<Film> film)
	{
		Category categoryExtra = new Category();
		categoryExtra.setFilm(film);
		em.persist(categoryExtra);
		return categoryExtra;
		
	}


}

















