package com.practice.dummy;

import java.util.ArrayList;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Client
{

	public static void main(String[] args) 
	{
		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("hello");
		EntityManager em = emf.createEntityManager();
		FSMService service = new FSMService(em);
		
		
		em.getTransaction().begin();
		
		
		List<Actor> actorList = new ArrayList<Actor>();
				
		Actor actorObject1 = service.createActor("Sudeep", "P","male", new Date(), null);
		Actor actorObject2 = service.createActor("Upendra", "P", "male", new Date(), null);
		
		actorList.add(actorObject1);
		actorList.add(actorObject2);

		
		
		Film filmObject1 = service.createFilm(new Date(), "Mass", "Kannada", (short)100, (byte)4, new Date(), "Ranna");
		Film filmObject2 = service.createFilm(new Date(), "Psychological", "Kannada", (short)120, (byte)4, new Date(), "Uppi2");
		
		
		List<Film> filmList = new ArrayList<Film>();
		filmList.add(filmObject1);
		filmList.add(filmObject2);
		
		
		Album albumObject1 = service.createAlbum("Kotigobba", new Date(), null);
		Album albumObject2 = service.createAlbum("Uppi2", new Date(), null);
		
		
		Category categoryObject = service.createCategory("Psychological", new Date(), null);
		List<Category> categoryList = new ArrayList<Category>();
		categoryList.add(categoryObject);

		
		Image imageObject1 = service.createImage("https://www.google.co.in", new Date(), null);
		List<Image> imageList = new ArrayList<Image>();
		imageList.add(imageObject1);
		
		Film filmObject3 = service.setFilmCredentials(/*"Ranna",*/actorList, categoryList, albumObject1);
		Actor actorObject3 = service.setActorCredentials(filmList, albumObject1);
		Album albumObject3 = service.setAlbumCredentials(imageList);
		Category categoryObject2 = service.setCategoryCredentials(filmList);
		
		em.getTransaction().commit();

		em.close();
		emf.close();
	}
	
}	
	/*public static void main(String[] args) 
	{
		List<Actor> actorList = new ArrayList<Actor>();
		//Actor actorObject1 = new Actor("salman", "khan", "male", null, new Date(), null, null);
		

		List<Film> filmList = new ArrayList<Film>();
		Film filmObject1 =  new Film("sultan", "UA", new Date(), "English", null, null, (byte) 4,null ,(short) 90,null, null);
		filmList.add(filmObject1);
		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("hello");
		EntityManager em = emf.createEntityManager();	
		

		em.getTransaction().begin();
		
		
		Actor actor = new Actor("salman", "khan", "male", null, new Date(), null, null);
		em.persist(actor);
		actorList.add(actor);
		
		Film film = new Film("sultan", "UA", new Date(), "English", actorList, null, (byte) 4,null ,(short) 90,null, null);
		em.persist(film);
		
		
		Album album = new Album("salman", null, new Date(), null);
		em.persist(album);
		
		Category category = new Category("Horror", new Date(), null);
		em.persist(category);
		
		Image image = new Image("https://www.google.co.in", new Date(), null);
		em.persist(image);
		
			
		
		
		em.getTransaction().commit();
		
		em.close();
		emf.close();
	}*/
//}

/*public class Client
{
	public static void main(String[] args) 
	{
		List<String> filmlist = new ArrayList<String>();
		filmlist.add("huchcha");
		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("hello");

		EntityManager em = emf.createEntityManager();

		
		Actor actor = new Actor(1,"Sudeep","P","male",new Album(),new Date(),null,null);
	
		Film film = new Film(1, "Kotigobba", null, new Date(), null, null, null, (byte)3, null, (short)100,null, new Date());
	
		
	}
}
*/