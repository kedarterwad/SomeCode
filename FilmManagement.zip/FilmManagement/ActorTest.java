package FilmManagement.FilmManagement;

import java.util.*;


import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class ActorTest {

	public static void main(String[] args) {
		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("hello");
		
		EntityManager em = emf.createEntityManager();
		FilmService service=new FilmService(em);
		
		em.getTransaction().begin();
		Image image1=service.createImage(1,"image1", null,null);
		Image image2=service.createImage(2,"image2",null,null);
		List<Image> img=new ArrayList<Image>();
		img.add(image1);
		img.add(image2);
		
		Image image3=service.createImage(3,"image3", null,null);
		Image image4=service.createImage(4,"image4",null,null);
		List<Image> newimg=new ArrayList<Image>();
		newimg.add(image3);
		newimg.add(image4);
	
		Album album1=service.createAlbum(3,"album1",null,null,img);
		Album album2=service.createAlbum(4,"album2",null,null,newimg);
		
		Actor actor1=service.createActor(1,"amitabh","bacchan","male",null,null,album1);
		Actor actor2=service.createActor(2,"abc","xyz","male",null,null,album2);
		List<Actor> actorlist=new ArrayList<Actor>();
		actorlist.add(actor1);
		actorlist.add(actor2);
		
		List<Category> cat1=new ArrayList<Category>();
		Category category1=service.createCategory(1,"category1",null,null);
		Category category2=service.createCategory(2,"category2",null,null);
		cat1.add(category1);
		cat1.add(category2);
		Film film1=new Film(1,"sholey","abcd","hindi",null,null,null,album2,120,actorlist,cat1,5);
		Film film2=service.createFilm(film1);

		System.out.println("persisted"+film2);
		em.getTransaction().commit();
		
		em.close();
		emf.close();
	}
}


