package FilmManagement.FilmManagement;

import java.util.Date;
import java.util.*;

import javax.persistence.*;
@Entity
public class Album {

	@Id 
	private int id;
	private String album_name;
	private Date createDate,deleteDate;
	@OneToMany
	//@JoinColumn (name="IMAGE_ID")
	List<Image>image;
	
	public Album(int id, String album_name, Date createDate, Date deleteDate, List<Image> image) {
		super();
		this.id = id;
		this.album_name = album_name;
		this.createDate = createDate;
		this.deleteDate = deleteDate;
		this.image = image;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getAlbum_name() {
		return album_name;
	}
	public void setAlbum_name(String album_name) {
		this.album_name = album_name;
	}
	public Date getCreateDate() {
		return createDate;
	}
	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}
	public Date getDeleteDate() {
		return deleteDate;
	}
	public void setDeleteDate(Date deleteDate) {
		this.deleteDate = deleteDate;
	}
	public List<Image> getImage() {
		return image;
	}
	public void setImage(List<Image> image) {
		this.image = image;
	}
	
	
	
	
}
