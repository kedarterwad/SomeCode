package FilmManagement.FilmManagement;

import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;


public class FilmService {
	protected EntityManager em;
	
	public FilmService(EntityManager em){
		this.em=em;
	}
public Film createFilm(Film film1){
		Film film=film1;
				/*film.setActor(actor);
				film.setAlbum(album);
				film.setCategory(category);
		*/
		em.persist(film);
		return film;
	}

public Actor createActor(int id, String fname,String lname,String gender,Date date1,Date date2,Album album){
	
	Actor actor=new Actor(id,fname,lname,gender,date1,date2,album);
	actor.setAlbum(album);
	em.persist(actor);
	return actor;
}
public Album createAlbum(int id,String album_name,Date date1,Date date2,List<Image>image)
{
	Album album=new Album(id,album_name,date1,date2,image);
	album.setImage(image);
	em.persist(album);
	return album;
	
}

public Category createCategory(int id,String category_name,Date date1,Date date2)
{
	Category category=new Category(id,category_name,date1,date2);
	em.persist(category);
	return category;
}
public Image createImage(int id,String imageUrl,Date date1,Date date2)
{
	Image image=new Image(id,imageUrl,date1,date2);
	em.persist(image);
	return image;
	
}
}
