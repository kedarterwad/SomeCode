package FilmManagement.FilmManagement;

import java.util.Date;
import javax.persistence.*;
@Entity
public class Category {

	@Id
	private int id;
	private String category_name;
	private Date createDate,deleteDate;
	public Category(int id, String category_name, Date createDate, Date deleteDate) {
		super();
		this.id = id;
		this.category_name = category_name;
		this.createDate = createDate;
		this.deleteDate = deleteDate;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getCategory_name() {
		return category_name;
	}
	public void setCategory_name(String category_name) {
		this.category_name = category_name;
	}
	public Date getCreateDate() {
		return createDate;
	}
	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}
	public Date getDeleteDate() {
		return deleteDate;
	}
	public void setDeleteDate(Date deleteDate) {
		this.deleteDate = deleteDate;
	}

	
	
	
}
