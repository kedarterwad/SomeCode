package FilmManagement.FilmManagement;

import java.util.Collection;
import java.util.Date;
import java.util.List;

import javax.persistence.*;
@Entity
public class Film {

	@Id 
	private int id;
	private String title,description,language;
	private Date release_year,createDate,deleteDate;
	@OneToOne
	@JoinColumn (name="ALBUM_ID")
	private Album album;
	
	private int length;
	@ManyToMany
	@JoinColumn (name="ACTOR_ID")
	List<Actor> actor;
	
	@ManyToMany
	@JoinColumn (name="CATEGORY_ID")
	List<Category> category;
	
	private int rating;
	
	public Film() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Film(int id, String title, String description, String language, Date release_year, Date createDate,
			Date deleteDate, Album album, int length, List<Actor> actorlist, List<Category> cat1, int rating) {
		super();
		this.id = id;
		this.title = title;
		this.description = description;
		this.language = language;
		this.release_year = release_year;
		this.createDate = createDate;
		this.deleteDate = deleteDate;
		this.album = album;
		this.length = length;
		this.actor = actorlist;
		this.category = cat1;
		this.rating = rating;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getLanguage() {
		return language;
	}
	public void setLanguage(String language) {
		this.language = language;
	}
	public Date getRelease_year() {
		return release_year;
	}
	public void setRelease_year(Date release_year) {
		this.release_year = release_year;
	}
	public Date getCreateDate() {
		return createDate;
	}
	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}
	public Date getDeleteDate() {
		return deleteDate;
	}
	public void setDeleteDate(Date deleteDate) {
		this.deleteDate = deleteDate;
	}
	public Album getAlbum() {
		return album;
	}
	public void setAlbum(Album album) {
		this.album = album;
	}
	public int getLength() {
		return length;
	}
	public void setLength(short length) {
		this.length = length;
	}
	public Collection<Actor> getActor() {
		return actor;
	}
	public void setActor(List<Actor> actor) {
		this.actor = actor;
	}
	public Collection<Category> getCategory() {
		return category;
	}
	public void setCategory(List<Category> category) {
		this.category = category;
	}
	public int getRating() {
		return rating;
	}
	public void setRating(byte rating) {
		this.rating = rating;
	}
	
	
	
}
