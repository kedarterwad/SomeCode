package FilmManagement.FilmManagement;


import java.util.Date;
import java.util.List;

import javax.persistence.*;
@Entity
public class Actor {

	@Id 
	private int id;
	private String firstName,lastName,gender;
	private Date createDate,deleteDate;
	@OneToOne
	@JoinColumn (name="ALBUM_ID")
	private Album album;
	@ManyToMany
	@JoinColumn(name="FILM_ID")
		private List<Film> film;
	
	public Actor(int id, String firstName, String lastName, String gender, Date createDate, Date deleteDate,Album album) {
		super();
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;
		this.createDate = createDate;
		this.deleteDate = deleteDate;
		this.album = album;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public Date getCreateDate() {
		return createDate;
	}
	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}
	public Date getDeleteDate() {
		return deleteDate;
	}
	public void setDeleteDate(Date deleteDate) {
		this.deleteDate = deleteDate;
	}
	public Album getAlbum() {
		return album;
	}
	public void setAlbum(Album album) {
		this.album = album;
	}
	public List<Film> getFilm() {
		return film;
	}
	public void setFilm(List<Film> film) {
		this.film = film;
	}

}
